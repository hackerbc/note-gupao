package com.gupaoedu.vip.pattern.template.course;

/**
 * Created by Tom.
 */
public class JavaCourse extends NetworkCourse {
    void checkHomework() {
        System.out.println("检查Java的架构课件");
    }
}
