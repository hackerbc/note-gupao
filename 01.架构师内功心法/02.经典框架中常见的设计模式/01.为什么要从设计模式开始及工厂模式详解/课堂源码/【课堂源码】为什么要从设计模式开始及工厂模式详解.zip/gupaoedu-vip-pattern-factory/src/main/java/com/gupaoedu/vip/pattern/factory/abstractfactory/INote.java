package com.gupaoedu.vip.pattern.factory.abstractfactory;

/**
 * 课堂笔记
 * Created by Tom.
 */
public interface INote {
    void edit();
}
