package com.gupaoedu.vip.pattern.proxy.simpleproxy;

/**
 * Created by Tom.
 */
public interface Subject {
    void request();
}
