package com.gupaoedu.vip.pattern.proxy;

/**
 * Created by Tom on 2019/3/10.
 */
public interface Person {

    void findLove();
}
