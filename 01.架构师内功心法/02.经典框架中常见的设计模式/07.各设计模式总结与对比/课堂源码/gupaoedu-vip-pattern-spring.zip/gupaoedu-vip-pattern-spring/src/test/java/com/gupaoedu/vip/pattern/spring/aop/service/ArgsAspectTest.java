package com.gupaoedu.vip.pattern.spring.aop.service;

/**
 * Created by Tom.
 */
public class ArgsAspectTest {
}
