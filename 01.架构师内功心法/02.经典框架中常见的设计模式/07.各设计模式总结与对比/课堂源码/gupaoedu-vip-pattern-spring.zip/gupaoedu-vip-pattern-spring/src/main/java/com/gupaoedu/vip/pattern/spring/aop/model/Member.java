package com.gupaoedu.vip.pattern.spring.aop.model;

public class Member {

}
