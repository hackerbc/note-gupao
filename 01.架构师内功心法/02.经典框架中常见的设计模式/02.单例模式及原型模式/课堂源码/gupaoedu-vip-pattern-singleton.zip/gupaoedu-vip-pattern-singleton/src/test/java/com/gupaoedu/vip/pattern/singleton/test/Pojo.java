package com.gupaoedu.vip.pattern.singleton.test;

/**
 * Created by Tom.
 */
public class Pojo {
}
