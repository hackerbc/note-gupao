package com.gupaoedu.vip.pattern.observer.events.mouseevent;

import com.gupaoedu.vip.pattern.observer.events.core.EventLisenter;

/**
 * Created by Tom.
 */
public class Keybord extends EventLisenter {

    public void down(){

    }

    public void up(){

    }

}
